<?php 

$conn = mysqli_connect("localhost", "root", "", "app");

if (!$conn) {
    echo "Connection Failed";
}
?>
