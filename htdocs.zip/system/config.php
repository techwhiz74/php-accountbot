<?php 

$conn = mysqli_connect("localhost", "root", "", "accountplug");

if (!$conn) {
    echo "Connection Failed";
}
?>
